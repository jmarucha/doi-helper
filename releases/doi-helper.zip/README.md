# doi-helper
 A little add-on appending SciHub buttons for some webpages with s c i e n c e.